<div id="pagewidget" class="searchbox">
  
  <form method="post" action="/search/" class="font-montserrat" style="display:inline">
<div style="display:inline-block;vertical-align:top;margin-right:12px;"><label for="generic">Listing Number:</label>&nbsp;&nbsp;<input name=id id="generic" style="width:65px;"> <input type=submit value="Search" class="theme-button1-dk" style="margin-left:25px; padding:4px 8px;border-radius:8px;border:0;" />
<input type=submit name="add_to_portfolio" value="Add" class="theme-button1-dk" style="margin-left:25px; padding:4px 8px;border-radius:8px;border:0;" /></form>
</div>

<div></div>

</div>
<div style="height:10px;"></div>
